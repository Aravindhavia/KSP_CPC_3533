using System;
using DevExpress.XtraReports.UI;

namespace KSPRecruitment.Application.Features.ApplicantFeatures.Reports
{
    public partial class KSP3533
    {
        public KSP3533()
        {
            InitializeComponent();
        }
    }
}
